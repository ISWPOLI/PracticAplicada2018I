import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
/**
 *  implementacion de las ecuaciones y sus operaciones
 * @author Michael Rodriguez y Felipe padilla
 *
 */
public class Ecuaciones {
	private static double segundaEcuacion;
	private static double terceraEcuacion;
	private static double cuartaEuacion;
	private static int evaluados;
	public static int a�oInicial=2005;
	public static int a�oSiguiente=2006;
	private static double evaluadosA�o2005=450.720;
	private static double evaluadosA�o2006=467.272;
	private static double evaluadosA�o2007=511.366;
	private static double evaluadosA�o2008=506.120;
	private static double evaluadosA�o2009=587.268;
	private static double evaluadosA�o2010=30199;
	private static  ArrayList<Double> puntajes = new ArrayList<Double>();
	private static  ArrayList<Integer> frecuenciaMatematicas = new ArrayList<Integer>();
	private static ArrayList<Double> puntajeDepartamento = new ArrayList<Double>();
	private static  ArrayList<Double> PrimeraOperacionE4 = new ArrayList<Double>();
	public static String departamento ;
	public static String a�oEvaluado ;
	public static String municipio;
	public static String materia;
	public static double puntajeFinal;
	public Ecuaciones(String departamento,String municipio,String a�o) throws SQLException {
		new OperacionesPuntajes(departamento,municipio, a�o);
		setA�oEvaluado(a�o);
		setDepartamento(departamento);
		setMunicipio(municipio);
		segundaEcuacion();
		frecuencia(OperacionesPuntajes.getPuntajeMatematicas());
		PrimeraOperacionE4(OperacionesPuntajes.getPuntajeMatematicas());
		terceraEcuacion();
		cuartaEcuacion(PrimeraOperacionE4(OperacionesPuntajes.getPuntajeMatematicas()));
		implementaccion_operaciones();
	}
	public static double segundaEcuacion() {	
		double diferencia = evaluadosA�o2005 - evaluadosA�o2006;
		double diferencia2 = evaluadosA�o2006 - evaluadosA�o2007;
		if (evaluadosA�o2005<evaluadosA�o2006) {
			diferencia = diferencia*-1;
		}
		if (evaluadosA�o2006>evaluadosA�o2007) {
			diferencia2 = diferencia2*-1;
		}
		segundaEcuacion = diferencia2;
		return segundaEcuacion;
	}
	public static double terceraEcuacion() {
		int aux1=OperacionesPuntajes.getEvaluadosDepartamento();
		int aux2=OperacionesPuntajes.getEvaluadosPeriodo();
		terceraEcuacion = (aux1)*100/(aux2)*100;
		return terceraEcuacion;
	}
	public static double cuartaEcuacion(ArrayList<Double> primeraOperacionE42) { 
		double sumaPrimeraOPE4=0;
		double operacionAux;
		for(int i=0;i<primeraOperacionE42.size();i++){ 
			double valor ;
			try{
				valor = (primeraOperacionE42.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			sumaPrimeraOPE4+=valor;
		}
		operacionAux = sumaPrimeraOPE4 / OperacionesPuntajes.getEvaluadosDepartamento();
		cuartaEuacion = Math.sqrt(operacionAux);
		return cuartaEuacion;
	}

	public ArrayList<Double> PrimeraOperacionE4(ArrayList<Double> puntajesArea) {
		for (int i = 0; i < puntajesArea.size(); i++) {
			for (int j = 0; j < OperacionesPuntajes.getListafrecuenciaRangos().size(); j++) {
				PrimeraOperacionE4.add(i,Math.pow(puntajesArea.get(i),2)*OperacionesPuntajes.getListafrecuenciaRangos().get(j));
			}
		}
		return PrimeraOperacionE4;
	}
	public static   ArrayList<Integer> frecuencia(List<Double> materia){
		Set<Double> auxiliar = new HashSet<Double>(materia);
		for (Double key : auxiliar) {
			puntajes.add(key);
			frecuenciaMatematicas.add(Collections.frequency(materia, key));
		}
		return frecuenciaMatematicas;
	}
	public static double implementaccion_operaciones() {
		//ccon ayudas de tablas dinamicas se estudiaron los promedios con mas acumulacion de los a�os.
		double [] rangoAceptado = {3.0,3.5,4.0,4.5,5.0,5.5};
		double rangoSuperiorAceptado = 55.0;
		boolean margenError = false;
		double promedioGM = OperacionesPuntajes.getPromedioMatematicas();
		double promedioGF = OperacionesPuntajes.getPromedioFisica();
		double promedioGB = OperacionesPuntajes.getPromedioBiologia();
		double promedioGL = OperacionesPuntajes.getPromedioLenguaje();
		double promedio_D_M = OperacionesPuntajes.getPromedio_Depar_Muni();
		double aux =Math.sqrt(getCuartaEuacion());
		double proFinal = (promedioGB+promedioGF+promedioGL+promedioGM+promedio_D_M)/5;
		puntajeFinal = proFinal;
		double diferencia = (promedio_D_M - puntajeFinal);
		if (puntajeFinal>rangoSuperiorAceptado) {
			puntajeFinal = puntajeFinal - diferencia;
		}
		if (puntajeFinal<promedio_D_M) {
			puntajeFinal = puntajeFinal + (diferencia)/2; 
		}
		return puntajeFinal;
	}
	/**
	 * NO BORRAR!!
	 */
	public static String getDepartamento() {
		return departamento;
	}
	public static double getPuntajeFinal() {
		return puntajeFinal;
	}
	public static String getMunicipio() {
		return municipio;
	}
	public static void setMunicipio(String municipio) {
		Ecuaciones.municipio = municipio;
	}
	public static void setDepartamento(String departamento) {
		Ecuaciones.departamento = departamento;
	}
	public static String getA�oEvaluado() {
		return a�oEvaluado;
	}
	public static void setA�oEvaluado(String a�oEvaluado) {
		Ecuaciones.a�oEvaluado = a�oEvaluado;
	}
	public static ArrayList<Double> getPuntajeDepartamento() {
		return puntajeDepartamento;
	}
	public static ArrayList<Double> getPrimeraOperacionE4() {
		return PrimeraOperacionE4;
	}
	public static ArrayList<Double> getPuntajes() {
		return puntajes;
	}
	public static ArrayList<Integer> getFrecuencia() {
		return frecuenciaMatematicas;
	}
	public static int getEvaluados() {
		return evaluados;
	}
	public static double getSegundaEcuacion() {
		return segundaEcuacion;
	}
	public static double getTerceraEcuacion() {
		return terceraEcuacion;
	}
	public static double getCuartaEuacion() {
		return cuartaEuacion;
	}

}
