import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.swing.plaf.synth.SynthSpinnerUI;

import org.omg.Messaging.SYNC_WITH_TRANSPORT;
/**
 * 
 * @author Michael
 *
 */
public class EntradaDatos {

	public static void main(String[] args) throws SQLException{
		long inicio = System.currentTimeMillis();
		String departamento ="CUNDINAMARCA";
		String municipio="FUNZA";
		String a�o  = "20051";
		new Ecuaciones(departamento,municipio,a�o);
		new OperacionesPuntajes(departamento,municipio,a�o);
		System.out.println(departamento);
		System.out.println(municipio);
		System.out.println(".......................................................................................");
		System.out.println("pruebas datos(solo para visualizar resultados)");
		System.out.println("promedio BIOLOGIA:  "+ OperacionesPuntajes.getPromedioBiologia());
		System.out.println("promedio LENGUAJE:  "+OperacionesPuntajes.getPromedioLenguaje());
		System.out.println("promedio FISICA  :  "+OperacionesPuntajes.getPromedioFisica());
		System.out.println("promedio  :  "+OperacionesPuntajes.getPromedioMatematicas());
		System.out.println("frecuencias rangos  : "+OperacionesPuntajes.getListafrecuenciaRangos());
		System.out.println("promedio depar y muni :"+OperacionesPuntajes.getPromedio_Depar_Muni());
		System.out.println("........................................................");
		
		
		
		System.out.println("-------------------!!RESULTADO!!---------------------------");
		System.out.println("...........................................................");
		System.out.println("prediccion siguiente periodo");
		System.out.println("...........................................................");
		System.out.println("departamento : "+departamento);
		System.out.println("municipio : "+municipio);
		System.out.println("...........................................................");
		System.out.println("final puntaje : "+Ecuaciones.getPuntajeFinal());

		
		System.out.println("--------------TIEMPO EJECUCION-----------------------------");
		long fin = System.currentTimeMillis();
		double tiempo = (double) ((fin - inicio)/1000);
		System.out.println();
		System.out.println();
		System.out.println(tiempo +" segundos");
		if (tiempo>60.0) {
			System.out.println("minutos :"+tiempo/60);
		}
	}
}


