import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
/**
 * 
 * @author Michael Rodriguez y felipe padilla
 *
 */
public class OperacionesPuntajes {
	private static  ArrayList<Double> puntajeMatematicas = new ArrayList<Double>();
	private static  ArrayList<Double> puntajeFisica = new ArrayList<Double>();
	private static  ArrayList<Double> puntajeLenguaje = new ArrayList<Double>();
	private static  ArrayList<Double> puntajeBiologia = new ArrayList<Double>();
	private static ArrayList<Double> puntaje_Depar_Muni = new ArrayList<Double>();
	private static double promedio_Depar_Muni;
	private static double promedioBiologia;
	private static double promedioLenguaje;
	private static double promedioFisica;
	private static double promedioMatematicas;
	private static int evaluadosDepartamento;
	private static int evaluadosPeriodo;
	public static String departamento ;
	public static String a�oEvaluado ;
	public static String municipio;
	public static String materia = "MATEMATICAS";
	private static 	int frecuenciasRangos [] = new int [101];
	private static ArrayList<Integer> ListafrecuenciaRangos = new ArrayList<Integer>();
	private static double terceraEcuacion;
	public static boolean margen_Error = false;
	public static double prediccionAux ;
	/**
	 * Este constructor realiza el select a la base de datos principal
	 * y para los parametros de conexion y statement,preparedStatement a cada metodo
	 * @throws SQLException
	 */
	public  OperacionesPuntajes(String departamento,String municipio,String a�o) throws SQLException{
		setA�oEvaluado(a�o);
		setDepartamento(departamento);	
		setMunicipio(municipio);
		new conexionMySql();
		Connection auxConexion = conexionMySql.getConnection();
		Statement sentencia = (Statement) auxConexion.createStatement(); 
		PreparedStatement prepararSentencia = null; 
		String consulta = "SELECT * FROM resultadosicfes;";
		ResultSet resultadoConsulta = sentencia.executeQuery(consulta);	
		promedio_Depar_Muni(resultadoConsulta,auxConexion,prepararSentencia,departamento,municipio);
		promedioMatematicas(resultadoConsulta,auxConexion,prepararSentencia,departamento,a�o);
		promedioFisica(resultadoConsulta, auxConexion, prepararSentencia,departamento,a�o);
		promedioLenguaje(resultadoConsulta, auxConexion, prepararSentencia,departamento,a�o);
		promedioBiologia(resultadoConsulta, auxConexion, prepararSentencia,departamento,a�o);
		ListafrecuenciaRangos(puntajeMatematicas);
		evaluadosDepartamento(resultadoConsulta, auxConexion, prepararSentencia,departamento);
		evaluadosPeriodo(resultadoConsulta, auxConexion, prepararSentencia);
	}
	public static int evaluadosPeriodo(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia) {
		try {
			String registros ="select count(*) from resultadosicfes where PERIODO = 20051;";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			if (resultadoConsulta.next()) {
				evaluadosPeriodo = resultadoConsulta.getInt(1);
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}	
		return evaluadosPeriodo;
	}
	public static double evaluadosDepartamento(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia,String departamento) {
		String depar = "'"+departamento+"'";
		try {
			String registros ="select count(*) from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			if (resultadoConsulta.next()) {
				evaluadosDepartamento = resultadoConsulta.getInt(1);
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}	
		return evaluadosDepartamento;
	}
	public static ArrayList<Integer> ListafrecuenciaRangos(ArrayList<Double> arrayList) {
		int limiteInferior =  0;
		double limiteSuperior = 0.99;
		int rango =0;
		while(limiteInferior<=99) {
			for (int i = 0; i <arrayList.size(); i++) {
				if (arrayList.get(i) >limiteInferior && arrayList.get(i) <= limiteSuperior) {
					rango++;
					frecuenciasRangos[limiteInferior]=rango;
				}
			}
			limiteSuperior = limiteSuperior +1;
			limiteInferior++;
			if (rango>0) {
				rango=0;
			}
			//System.out.println(limiteInferior+"-------"+limiteSuperior);
		}
		for (int i = 0; i < frecuenciasRangos.length; i++) {
			ListafrecuenciaRangos.add(i, frecuenciasRangos[i]);	
		}		
		return ListafrecuenciaRangos ;
	}
	public static double promedio_Depar_Muni(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia,String departamento,String municipio) {
		String depar = "'"+departamento+"'";
		String munici   = "'"+municipio+"'";
		String area = "PUNT_"+materia;
		try {
			int contador=0; 
			String registros ="select * from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+" AND ESTU_RESIDE_MCPIO = "+munici+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			while (resultadoConsulta.next()){
				puntaje_Depar_Muni.add(contador,resultadoConsulta.getDouble (area));
				contador++;
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}
		double auxSuma=0;
		for(int i=0;i<puntaje_Depar_Muni.size();i++){ 
			double valor ;
			try{
				valor = (puntaje_Depar_Muni.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			auxSuma+=valor;
			promedio_Depar_Muni = auxSuma / puntaje_Depar_Muni.size();
		}
		return promedio_Depar_Muni;
	}
	public static double promedioBiologia(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia,String departamento,String a�o) {		
		String depar = "'"+departamento+"'";
		String a�oEvaluado   = ""+a�o+"";
		try {
			int contador=0;
			String registros ="select * from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+"AND PERIODO = "+a�oEvaluado+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			while (resultadoConsulta.next()){
				puntajeBiologia.add(contador,resultadoConsulta.getDouble ("PUNT_BIOLOGIA"));
				contador++;
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}
		double auxSuma=0;
		for(int i=0;i<puntajeBiologia.size();i++){ 
			double valor ;
			try{
				valor = (puntajeBiologia.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			auxSuma+=valor;
			promedioBiologia = auxSuma / puntajeBiologia.size();
		}
		return promedioBiologia;
	}
	public  static double promedioLenguaje(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia,String departamento,String a�o) {
		String depar = "'"+departamento+"'";
		String a�oEvaluado   = ""+a�o+"";
		try {
			int contador=0;
			String registros ="select * from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+"AND PERIODO = "+a�oEvaluado+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			while (resultadoConsulta.next()){
				puntajeLenguaje.add(contador,resultadoConsulta.getDouble ("PUNT_LENGUAJE"));
				contador++;
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}
		double auxSuma=0;
		for(int i=0;i<puntajeLenguaje.size();i++){ 
			double valor ;
			try{
				valor = (puntajeLenguaje.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			auxSuma+=valor;
			promedioLenguaje = auxSuma / puntajeLenguaje.size();
		}
		return promedioLenguaje;
	}
	public  static double promedioFisica(ResultSet resultadoConsulta, Connection auxConexion,
			PreparedStatement prepararSentencia,String departamento,String a�o) {
		String depar = "'"+departamento+"'";
		String a�oEvaluado   = ""+a�o+"";
		try {
			int contador=0;
			String registros ="select * from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+"AND PERIODO = "+a�oEvaluado+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();

			while (resultadoConsulta.next()){
				puntajeFisica.add(contador,resultadoConsulta.getDouble ("PUNT_FISICA"));
				contador++;
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}
		double auxSuma=0;
		for(int i=0;i<puntajeFisica.size();i++){ 
			double valor ;
			try{
				valor = (puntajeFisica.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			auxSuma+=valor;
			promedioFisica = auxSuma / puntajeFisica.size();
		}
		return promedioFisica;
	}
	public static double promedioMatematicas(ResultSet resultadoConsulta, Connection auxConexion, 
			PreparedStatement prepararSentencia,String departamento,String a�o){
		String depar = "'"+departamento+"'";
		String a�oEvaluado   = "'"+a�o+"'";
		try {
			int contador=0;
			String registros ="select * from resultadosicfes where ESTU_RESIDE_DEPTO ="+depar+"AND PERIODO = "+a�oEvaluado+"";
			prepararSentencia= (PreparedStatement) auxConexion.prepareStatement(registros);
			resultadoConsulta = prepararSentencia.executeQuery();
			while (resultadoConsulta.next()){
				puntajeMatematicas.add(contador,resultadoConsulta.getDouble ("PUNT_MATEMATICAS"));
				contador++;
			}
		}catch (Exception e) {
			System.out.println("OPERACION INVALIDA O DATOS ERRONEOS");
		}
		double auxSuma=0;
		for(int i=0;i<puntajeMatematicas.size();i++){ 
			double valor ;
			try{
				valor = (puntajeMatematicas.get(i));
			}
			catch(NumberFormatException e){
				valor = (double) 0;
			}
			auxSuma+=valor;
			promedioMatematicas = auxSuma / puntajeMatematicas.size();
		}
		return promedioBiologia;
	}
	/**
	 * 
	 * NO BORRAR!!
	 */
	public static double getTerceraEcuacion() {
		return terceraEcuacion;
	}
	public static double getPrediccionAux() {
		return prediccionAux;
	}
	public static void setPrediccionAux(double prediccionAux) {
		OperacionesPuntajes.prediccionAux = prediccionAux;
	}
	public static String getMunicipio() {
		return municipio;
	}
	public static void setMunicipio(String municipio) {
		OperacionesPuntajes.municipio = municipio;
	}
	public static String getMateria() {
		return materia;
	}
	public static void setMateria(String materia) {
		OperacionesPuntajes.materia = materia;
	}
	public static double getPromedio_Depar_Muni() {
		return promedio_Depar_Muni;
	}
	public static String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public static String getA�oEvaluado() {
		return a�oEvaluado;
	}
	public void setA�oEvaluado(String a�oEvaluado) {
		this.a�oEvaluado = a�oEvaluado;
	}
	public static int getEvaluadosDepartamento() {
		return evaluadosDepartamento;
	}
	public static int getEvaluadosPeriodo() {
		return evaluadosPeriodo;
	}
	public static ArrayList<Integer> getListafrecuenciaRangos() {
		return ListafrecuenciaRangos;
	}
	public static int[] getFrecuenciasRangos() {
		return frecuenciasRangos;
	}
	public static double getPromedioLenguaje() {
		return promedioLenguaje;
	}
	public static double getPromedioFisica() {
		return promedioFisica;
	}
	public static double getPromedioMatematicas() {
		return promedioMatematicas;
	}
	public static double getPromedioBiologia() {
		return promedioBiologia;
	}
	public static ArrayList<Double> getPuntajeBiologia() {
		return puntajeBiologia;
	}
	public static ArrayList<Double> getPuntajeFisica() {
		return puntajeFisica;
	}
	public static ArrayList<Double> getPuntajeLenguaje() {
		return puntajeLenguaje;
	}
	public static ArrayList<Double> getPuntajeMatematicas() {
		return puntajeMatematicas;
	}
}
