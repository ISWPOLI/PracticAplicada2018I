import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
/**
 * 
 * @author Michael
 *
 */

public class conexionMySql {
	/**
	 * aca ingresar los datos de la base de datos a usar, usuario,password, nombre de la base
	 * el nombre de l tabla cambiarlo en las clases OperacionesPuntajes y Ecuaciones
	 * "SELECT * FROM !!nombre table!!;"
	 */
	private static Connection auxConectar;
	private static final String driver= "com.mysql.jdbc.Driver";
	private static final String usuario="root"; 
	private static final String password="12345";
	private static final String  url="jdbc:mysql://localhost:3306/icfes";
	/**
	 * Establecer la conexion con la base de datos
	 */
	public conexionMySql(){

		auxConectar = null;

		try {
			Class.forName(driver);
			auxConectar = (Connection) DriverManager.getConnection(url, usuario, password);

			if (auxConectar!= null) {
				System.out.println("Conexion establecida");
			}

		}catch (ClassNotFoundException 	| SQLException e) {
			System.out.println("Error al establecer la conexion");

		}
	}

	public static  Connection getConnection() {
		return auxConectar;
	}

	public void desconectar() {
		auxConectar = null;
		if (auxConectar==null) {
			System.out.println("Conexion terminada");
		}
	}
}
